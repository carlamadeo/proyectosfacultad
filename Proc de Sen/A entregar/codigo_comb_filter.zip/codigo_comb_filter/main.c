/* Calcula los BPM de un audio. */

#include <getopt.h>
#include "bpm.h"

struct option longopts[] = {
	{"hiphop", false, NULL, HIPHOP},
	{"rock", false, NULL, ROCK},
	{"house", false, NULL, HOUSE},
	{"trance", false, NULL, TRANCE},
};

/**
*  Imprime la version.
*/
void imprime_version(){
	printf("BPM %s, Procesamiento de Señales\n", bpm_version);
}

/**
*  Imprime la ayuda.
*/
void imprime_ayuda(){
	printf("\nCalcula los BPM.\n\n");
	printf("Uso: bpm [opciones] archivo\n\nOpciones:\n");
	printf("	-v		Imprimir la version.\n");
	printf("	-h		Imprimir la ayuda.\n");
	printf("	-t		Tipo de audio.\n");
	printf("	-r rate		El sample rate en Hz es [%i]\n", bpm_samplerate);
	printf("	-c canales	El número de canales es [%i]\n", bpm_canales);	
	printf("	-i inicio	Empezar a analizar al segundo [%.2f]\n", bpm_inicio);
	printf("	-f fin		Parar de analizar al segundo [%.2f]\n", bpm_fin);
	printf("	-m min		El mínimo BPM testeado es [%.1f]\n", bpm_minbpm);
	printf("	-x max		El máximo BPM testeado es [%.1f]\n", bpm_maxbpm);
	printf("	-u muestra	Factor de muestra (cuanto mas alto, mas rapido y menos cierto) [%i]\n", bpm_muestreo);
	printf("	-b beats	Beats por compás (3 para el Vals) [%i]\n", bpm_beatsxcompas);
}

/**
*  Comienzo del main.
*/
int main(int argc, char *args[]){
	
	char opcion, *opcs = "vht:r:c:s:e:m:x:d:b:"; int index;
	
	while((opcion = getopt_long(argc, args, opcs, longopts, &index)) != -1){  
		
		switch(opcion){			
			case 'v':  //imprime la versión
				imprime_version();
				exit(1);
			case 'h':  //imprime la ayuda
				imprime_ayuda();
				exit(1);
			case 't':  //formatea el tipo
				bpm_formato = optarg;
				break;
			case 'r':  //sample rate
				bpm_samplerate = atoi(optarg);
				break;
			case 'c':  //canales
				bpm_canales = atoi(optarg);
				break;
			case 'i':  //inicio
				bpm_inicio = atof(optarg);
				break;
			case 'f':  //fin
				bpm_fin = atof(optarg);
				break;
			case 'm':  //minimo bpm
				bpm_minbpm = atof(optarg);
				break;
			case 'x':  //maximo bpm
				bpm_maxbpm = atof(optarg);
				break;
			case 'u':  //factor de muestra
				bpm_muestreo = atoi(optarg);
				break;
			case 'b':  //beats por medicion			
				bpm_beatsxcompas = atoi(optarg);
				break;
			case HIPHOP: case ROCK: case HOUSE: case TRANCE:
				bpm_tempo_preset((Tempo)opcion);
				break;
			default: break;
		}
	}
	
	if(args[optind] == 0){  //no hay archivo
		imprime_ayuda();
		exit(0);
	}
	
	if(bpm_inicio >= bpm_fin)  //chequea inicio y fin
		bpm_fin = bpm_inicio + 10;
	
	if(bpm_maxbpm >= bpm_minbpm)  //chequea limites
		bpm_maxbpm = bpm_minbpm + 10;
		
	Stream *stream = bpm_stream(args[optind]);  //convierte a pcm
	bpm_stream_print(stream);
	printf("%.1f\n", bpm(stream));  //Calcula los bpm
	
	free(stream); 
	return 1;
}
