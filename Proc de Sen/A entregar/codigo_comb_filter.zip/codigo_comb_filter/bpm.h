/* Calcula los BPM de un audio. */

#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <lame/lame.h>
#include <vorbis/vorbisfile.h>
#include <sndfile.h>

typedef enum { true = 1, false = 0} Boolean;  //booleanos
typedef enum { MP3, OGG, WAV, RAW} Format;  //formatos de archivo
typedef enum { HIPHOP, ROCK, HOUSE, TRANCE} Tempo;  //clasificaciones de tempos
typedef short Pcm;  //datos de audio

typedef struct {  //formato de input estandar para calculos de bpm
	int formato;
	int samplerate;
	int canales;
	int muestras;
	Pcm *pcm;
} Stream;

extern const char *bpm_version;  //numero de version

extern char *bpm_formato;  
extern int bpm_samplerate;  //sample rate por default
extern int bpm_canales;  //canales default (estereo)

extern float bpm_inicio;  //inicio
extern float bpm_fin;  //fin

extern float bpm_minbpm;  //ninimo a chequear
extern float bpm_maxbpm;  //maximo a chequear

extern int bpm_muestreo;  //factor de muestreo
extern int bpm_beatsxcompas;  //numero de beats por compas

/**
*  Inicializa constantes.
*/
extern void bpm_tempo_preset(Tempo p_preset);

/**
*  Retorna un puntero al stream
*/
extern Stream *bpm_stream(char *p_filename);
extern void bpm_stream_print(Stream *p_stream);
extern float bpm(Stream *p_stream);
