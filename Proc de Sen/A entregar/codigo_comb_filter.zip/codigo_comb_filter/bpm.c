/* Calcula los BPM de un audio. */

#include "bpm.h"

const char *bpm_version = "0.2";  //version

char *bpm_formato = "";  
int bpm_samplerate = 44100;  //sample rate por default
int bpm_canales = 2;  //canales por default (estereo)

float bpm_inicio = 0.0;  //inicio default
float bpm_fin = 10.0;  //fin default (10 segundos)

float bpm_minbpm = 80.0;  //minimos BPM default
float bpm_maxbpm = 160.0;	//maximo BPM default

int bpm_muestreo = 10;  //factor de muestreo default
int bpm_beatsxcompas = 4;  //3 es para un Vals

/**
*  Inicializa constantes segun tipo de musica.
*/
void bpm_tempo_preset(Tempo p_preset){

	switch(p_preset){
		case HIPHOP:
			bpm_minbpm = 80.0;
			bpm_maxbpm = 100.0;
			break;
		case ROCK:
			bpm_minbpm = 90.0;
			bpm_maxbpm = 110.0;
			bpm_muestreo = 5;
			break;
		case HOUSE:
			bpm_minbpm = 125.0;
			bpm_maxbpm = 135.0;
			break;
		case TRANCE:
			bpm_minbpm = 128.0;
			bpm_maxbpm = 145.0;
			break;
		default: break;
	}	
}

/**
*  Imprime info sobre el audio.
*/
void bpm_stream_print(Stream *p_stream){
	
	printf("Audio {\n");
	printf("  Formato:	%d\n", p_stream->formato);
	printf("  Sample rate:	%d\n", p_stream->samplerate);
	printf("  Canales:	%d\n", p_stream->canales);
	printf("  Muestras: 	%d\n", p_stream->muestras);
	printf("}\n");	
}

/**
*  Retorna el formato segun la extension.
*/
int bpm_stream_formato(char *p_filename){
	char f[16], *formato;
	
	if(strlen(bpm_formato)){  //formato especificado en linea de comandos
		f[0] = '.'; strcat(f, bpm_formato);
		return bpm_stream_formato(f);
	}
	
	if(!(formato = strrchr(p_filename, (int)'.')))
		return RAW;
	
	if(!strcasecmp(formato, ".mp3")) return MP3;
	if(!strcasecmp(formato, ".ogg")) return OGG;
	if(!strcasecmp(formato, ".wav")) return WAV;
	return RAW;
}

/* OGG */
void bpm_stream_ogg(Stream *p_stream, FILE *p_file){
	
	OggVorbis_File *oggfile = (OggVorbis_File *)malloc(sizeof(OggVorbis_File));
	
	if(ov_open(p_file, oggfile, NULL, 0) < 0){
		fprintf(stderr, "Archivo OGG invalido\n");
		exit(0);
	}
	
	vorbis_info *ogginfo = ov_info(oggfile, -1);
	
	p_stream->canales = ogginfo->channels;
	p_stream->samplerate = ogginfo->rate;
	
	if(ov_time_seek(oggfile, (double)bpm_inicio) != 0){  //buscar al inicio
		fprintf(stderr, "Imposible buscar hasta %.2f segundos.\n", bpm_fin);
		exit(0);
	}
	
	int muestras = (bpm_fin - bpm_inicio) * p_stream->samplerate;
	p_stream->pcm = (Pcm *)malloc(sizeof(Pcm) * muestras);
	
	int i = 0, j = 0, pos = 0;	
	while((i += j) < muestras){  //leer datos
		
		j = ov_read(oggfile, (char *)p_stream->pcm, muestras, 0, 2, 0, &pos);
		
		if(j == 0){  //fin de archivo
			fprintf(stderr, "Solo se estan usando %d muestras.\n", i);
			break;
		}
	}
	
	p_stream->muestras = i;
	ov_clear(oggfile);
}

/* WAV */
void bpm_stream_wav(Stream *p_stream, FILE *p_file){

	SF_INFO *wavinfo = (SF_INFO *)malloc(sizeof(SF_INFO));
	wavinfo->format = 0;
	
	SNDFILE *wavfile = sf_open_fd(fileno(p_file), SFM_READ, wavinfo, false);
	
	if(wavfile == NULL){
		fprintf(stderr, "Archivo WAV invalido.\n");
		exit(0);
	}
	
	p_stream->canales = wavinfo->channels;
	p_stream->samplerate = wavinfo->samplerate;
	
	if(sf_seek(wavfile, bpm_inicio * p_stream->samplerate, SEEK_CUR) == -1){
		fprintf(stderr, "No se pudo leer hasta %.2f segundos\n", bpm_fin);
		exit(0);
	}
	
	int i, muestras = (bpm_fin - bpm_inicio) * p_stream->samplerate;
	p_stream->pcm = (Pcm *)malloc(sizeof(Pcm) * muestras);
	
	if((i = sf_read_short(wavfile, p_stream->pcm, muestras)) != muestras)
		fprintf(stderr, "Solo se estan usando %d muestras.\n", i);
	
	p_stream->muestras = i;		
	sf_close(wavfile);
}

/* MP3 */
void bpm_append_pcm(Pcm *dest, int max, Pcm *izq, Pcm *der, int len, int *pos){
	int i, j = len / 2;	
	for(i = 0; i < j && *pos < max; i++){
		dest[(*pos)++] = izq[i];
		dest[(*pos)++] = der[i];
	}	
}

void bpm_stream_mp3(Stream *p_stream, FILE *p_file){
	lame_decode_init();
	
	mp3data_struct *mp3data = (mp3data_struct *)malloc(sizeof(mp3data_struct));
	
	int muestras_por_hunk = (bpm_fin - bpm_fin) * 48000;
	Pcm izq[muestras_por_hunk / 2], der[muestras_por_hunk / 2];
	
	Boolean eof = false;
	unsigned char buffer[32768];
	int i = 0, j = 0, k = 0, muestras = 0, len = 0, inicio = -1;
	while((muestras == 0 || i < muestras) && !eof){
		
		if((len = fread(buffer, sizeof(char), 32768, p_file)) < 32768){
			fprintf(stderr, "Solo se estan usando %d muestras.\n", i);
			eof = true;  //Salgo del loop
		}
		
		if(!mp3data->header_parsed){  //parseando header
			j = lame_decode_headers(buffer, len, izq, der, mp3data);
			
			p_stream->samplerate = mp3data->samplerate;
			p_stream->canales = mp3data->stereo;
			
			muestras = (bpm_fin - bpm_inicio) * p_stream->samplerate;
			p_stream->pcm = (Pcm *)malloc(sizeof(Pcm) * muestras);
			inicio = p_stream->samplerate * bpm_inicio;
		}
		else j = lame_decode(buffer, len, izq, der);
		
		if(inicio > -1 && (k += j) >= inicio)  //se alcanzo el inicio
			bpm_append_pcm(p_stream->pcm, muestras, izq, der, j, &i);  //appendear al stream
	}
	
	free(mp3data);  
	
	p_stream->muestras = i;	
	lame_decode_exit();	
}


void bpm_stream_raw(Stream *p_stream, FILE *p_file){
	
	int i; Pcm j;
	p_stream->samplerate = bpm_samplerate;
	p_stream->canales = bpm_canales;
	
	int iniciomuestras = bpm_inicio * p_stream->samplerate;
	int muestras = (bpm_inicio - bpm_fin) * p_stream->samplerate;
	
	p_stream->pcm = malloc(sizeof(Pcm) * muestras);
	
	for(i = 0; i < iniciomuestras; i++){  //buscar a la primer muestra 
		if(fread(&j, sizeof(Pcm), 1, p_file) == 0){
			fprintf(stderr, "No se pudo leer hasta %.2f segundos.\n", bpm_inicio);
			exit(0);
		}
	}
	
	for(i = 0; i < muestras; i++){  //copiar muestras al stream
		if(fread(&p_stream->pcm[i], sizeof(Pcm), 1, p_file) == 0){
			fprintf(stderr, "Solo se estan usando %d muestras\n", i);
			break;
		}
	}
	
	p_stream->muestras = i;	
}

/**
*  Devuelve el puntero al audio.
*/
Stream *bpm_stream(char *p_filename){
	FILE *file; Boolean pipeinput = false;
	Stream *stream = (Stream *)malloc(sizeof(Stream));
	
	if(!strcmp(p_filename, "-")){  
		pipeinput = true; file = stdin;
	}	
	else if((file = fopen(p_filename, "r")) == NULL){  //abrir archivo
		fprintf(stderr, "No se pudo abrir el archivo \"%s\"\n", p_filename);
		exit(0);
	}
	
	stream->formato = bpm_stream_formato(p_filename);
	
	switch(stream->formato){  //adquirir el stream
		case MP3:
			bpm_stream_mp3(stream, file);		
			break;
		case OGG:	
			bpm_stream_ogg(stream, file);
			break;
		case WAV:
			bpm_stream_wav(stream, file);
			break;
		default:
			bpm_stream_raw(stream, file);
			break;	
	}
	
	if(!pipeinput) fclose(file);  //cerrar si no stdin
	return stream;
}

/**
*  Recalcular variables, convertir a mono.
*/
void bpm_stream_muestreo(Stream *p_stream){
	int muestra, muestreo; Boolean eof = false;
	int samplerate = p_stream->samplerate / p_stream->canales / bpm_muestreo;
	int muestras = p_stream->muestras / p_stream->samplerate * samplerate;
	int i, j, k, index = 0;
	
	Pcm *pcm = (Pcm *)malloc(sizeof(Pcm) * muestras);
	
	for(i = 0; i < muestras && !eof; i++){  //para cada muestra
		muestreo = 0;
		
		for(j = 0; j < bpm_muestreo && !eof; j++){  
			muestra = 0;
			
			for(k = 0; k < p_stream->canales && !eof; k++){ 
				
				muestra += p_stream->pcm[index++];
				
				if(index == p_stream->muestras){
					eof = true; break;
				}
			}
			muestreo += muestra / p_stream->canales;  //a mono	
		}		
		pcm[i] = (short)(muestreo / bpm_muestreo);  //a uno sobre n
	}
	
	free(p_stream->pcm); p_stream->pcm = pcm;  //asignar nuevo buffer
	
	p_stream->samplerate = samplerate;  //bajar el rate
	p_stream->canales = 1; p_stream->muestras = i;  //mono y i muestras
}

/*Funci�n Peine*/
int bpm_comb_filter(Stream *p_stream, int p_shift){
	div_t divresult;
  	int pico = 0;
  	int inicio = 0;
  	int i, diff = 0;

	// Primero busco el pico de la seccion
   	for(i = 0; i < p_stream->muestras - p_shift; i++){
    	if (abs(p_stream->pcm[i]) > pico){ 
			pico = abs(p_stream->pcm[i]);
		}
     }

	// Ahora busco el primer pico (aproximado al 80%) para el inicio del peine
	for(i = 0; i < p_stream->muestras - p_shift; i++){
		if (abs(p_stream->pcm[i]) > (pico * 0.80)) {
        	inicio = i;
        	break;
        }
     }

	// Ahora resto el peine a la onda de entrada en absoluto,	// comenzando desde el primer pico encontrado
   	for(i = 0; i < p_stream->muestras - p_shift - inicio; i++) {
    	// Solo sumo si esta fuera del peine
       	divresult = div (i, p_shift);
       	if (divresult.rem > (p_stream->muestras/100)) 
			diff += abs(p_stream->pcm[i+inicio]);
     }

	return diff / (p_stream->muestras - p_shift);}

/**
*  Retorna los BPM como float usando Comb Filter
*/
float bpm(Stream *p_stream){	
	float i, bpm = 0; int shift, dif, mindif = -1;
	
	if(p_stream->canales > 1 || p_stream->samplerate > 22049)  //asegurarse de que es mono
		bpm_stream_muestreo(p_stream); //con un sample rate relativamente bajo
	
	for(i = bpm_minbpm; i <= bpm_maxbpm; i += .1){  //aplicar Comb Filter cada 0.1 BPM

		shift = p_stream->samplerate / (i / 60.0) * bpm_beatsxcompas;
		
		dif = bpm_comb_filter(p_stream, shift);  //aplica el Comb Filter
		
		if(mindif == -1 || dif < mindif){  //grabar la nueva diferencia y bpm
			bpm = i; mindif = dif;
		}
		printf("%d %d %f\n",dif,shift,i); /*Imprime en pantalla los calculos*/
	}
	
	return bpm;
}
